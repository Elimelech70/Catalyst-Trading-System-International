# Agent.py Patch Instructions

**Purpose:** Enable position monitoring by passing agent reference to tool_executor

---

## Change Required

Find the line in `agent.py` where `create_tool_executor` is called (usually in `run_cycle()` method):

### BEFORE:
```python
self.executor = create_tool_executor(
    cycle_id=self.cycle_id,
    alert_callback=alert_callback,
)
```

### AFTER:
```python
self.executor = create_tool_executor(
    cycle_id=self.cycle_id,
    alert_callback=alert_callback,
    agent=self,  # NEW: Pass self for position monitoring
)
```

---

## Alternative: Using ToolExecutor Directly

If using `ToolExecutor` class directly:

### BEFORE:
```python
self.executor = ToolExecutor(
    cycle_id=self.cycle_id,
    alert_callback=alert_callback,
)
```

### AFTER:
```python
self.executor = ToolExecutor(
    cycle_id=self.cycle_id,
    alert_callback=alert_callback,
    agent=self,  # NEW: Pass self for position monitoring
)
```

---

## What This Enables

By passing `agent=self`, the tool_executor can:

1. Access `self.client` (the Anthropic client) for Haiku consultations
2. Start position monitoring after successful BUY orders
3. Enable continuous monitoring until exit

---

## Verification

After making the change, verify by adding a debug log:

```python
# In agent.py run_cycle() method, after creating executor:
logger.info(f"Executor created with agent reference: {self.executor.agent is not None}")
```

Expected output:
```
Executor created with agent reference: True
```

---

## Rollback

If issues occur, simply remove `agent=self` and position monitoring will be disabled:

```python
self.executor = create_tool_executor(
    cycle_id=self.cycle_id,
    alert_callback=alert_callback,
    # agent=self,  # Disabled
)
```

The trade will still execute; only the continuous monitoring will be skipped.
