# Catalyst International - Bug Fix Implementation Guide

**Date:** 2026-01-08
**Author:** Claude (Opus 4.5)
**Issues:** Pattern Detection Broken + Odd Lot Sizing Errors

---

## Executive Summary

Two critical bugs are blocking new trades in the international system:

| Issue | Severity | Root Cause | Fix Complexity |
|-------|----------|------------|----------------|
| Pattern Detection | **CRITICAL** | `get_ohlcv()` method doesn't exist | Simple (1 line) |
| Odd Lot Sizing | **HIGH** | Hardcoded lot_size=100, but varies by stock | Medium (3 files) |

---

## Issue 1: Pattern Detection - SIMPLE FIX

### Problem
```
ERROR - Failed to get OHLCV for 3888: 'MarketData' object has no attribute 'get_ohlcv'
ERROR - Failed to get OHLCV for 1088: 'MarketData' object has no attribute 'get_ohlcv'
```

The `patterns.py` calls `self.market_data.get_ohlcv()` at line ~66, but `MarketData` class only has `get_historical()`.

### Solution
**File:** `catalyst-international/data/patterns.py`
**Line:** ~66

**Change FROM:**
```python
df = self.market_data.get_ohlcv(symbol, days=days)
```

**Change TO:**
```python
df = self.market_data.get_historical(symbol, timeframe="1d", bars=days)
```

### How to Apply
```bash
# SSH to droplet
ssh root@your-droplet-ip

# Edit the file
nano /root/catalyst-international/data/patterns.py

# Find the line (around line 66):
# df = self.market_data.get_ohlcv(symbol, days=days)

# Replace with:
# df = self.market_data.get_historical(symbol, timeframe="1d", bars=days)

# Also update the error message on the next line to be clearer:
# logger.error(f"Failed to get historical data for {symbol}: {e}")

# Save and exit (Ctrl+X, Y, Enter)
```

### Updated File Header
Update the version in patterns.py:
```python
"""
Name of Application: Catalyst Trading System
Name of file: patterns.py
Version: 1.2.0
Last Updated: 2026-01-08
Purpose: Chart pattern detection with relaxed breakout criteria

REVISION HISTORY:
v1.2.0 (2026-01-08) - Fix broken pattern detection
- CRITICAL FIX: Changed get_ohlcv() to get_historical() 
- MarketData class only has get_historical() method, not get_ohlcv()
- This fix restores all pattern detection functionality
...
"""
```

---

## Issue 2: Odd Lot Sizing - MEDIUM FIX

### Problem
```
ERROR - Order failed: The order you placed contains odd lot (less than 1 lot)
```

The system hardcodes `lot_size=100` for all stocks, but HKEX stocks have varying lot sizes:

| Stock | Code | Lot Size |
|-------|------|----------|
| Tencent | 0700 | 100 |
| CK Hutchison | 0001 | 500 |
| China Life | 2628 | **500** |
| Great Wall Motor | 2333 | 500 |
| Natural Dairy | 0462 | 4000 |

### Solution Overview
Three files need modification:

1. **moomoo.py** - Add `get_lot_size()` method to fetch from API
2. **market.py** - Update `get_quote()` to return actual lot size
3. **safety.py** - Use stock-specific lot size in validation

### Fix 2A: moomoo.py - Add get_lot_size() method

**Add after the `get_quote()` method (around line 200):**

```python
def get_lot_size(self, symbol: str) -> int:
    """Get the board lot size for a stock.
    
    HKEX stocks have varying lot sizes (100, 500, 1000, 2000, etc.)
    This fetches the actual lot size from the API.
    
    Args:
        symbol: Stock code (e.g., '700' or '2628')
        
    Returns:
        Board lot size (e.g., 100 for Tencent, 500 for China Life)
    """
    if not self._connected:
        raise RuntimeError("Not connected to OpenD")
    
    # Format symbol for Moomoo
    moomoo_symbol = self._format_hk_symbol(symbol)
    
    # Use get_stock_basicinfo to fetch lot size
    ret, data = self.quote_ctx.get_stock_basicinfo(
        Market.HK, 
        SecurityType.STOCK,
        [moomoo_symbol]
    )
    
    if ret != RET_OK:
        logger.warning(f"Failed to get lot size for {symbol}: {data}")
        return 100  # Default fallback
    
    if data is not None and len(data) > 0:
        lot_size = int(data['lot_size'].iloc[0])
        logger.debug(f"Lot size for {symbol}: {lot_size}")
        return lot_size
    
    logger.warning(f"No lot size data for {symbol}, using default 100")
    return 100
```

**Also update `execute_trade()` to use dynamic lot size (around line 280):**

**Change FROM:**
```python
# Validate lot size (HKEX requires multiples of 100)
if quantity % 100 != 0:
    logger.warning(f"Adjusting quantity {quantity} to nearest lot of 100")
    quantity = (quantity // 100) * 100
    if quantity == 0:
        quantity = 100
```

**Change TO:**
```python
# Validate lot size (HKEX requires multiples of board lot)
actual_lot_size = self.get_lot_size(symbol)
if quantity % actual_lot_size != 0:
    logger.warning(f"Adjusting quantity {quantity} to nearest lot of {actual_lot_size}")
    quantity = (quantity // actual_lot_size) * actual_lot_size
    if quantity == 0:
        quantity = actual_lot_size
```

### Fix 2B: market.py - Return actual lot size in get_quote()

**File:** `catalyst-international/data/market.py`
**Method:** `get_quote()`

**Change FROM:**
```python
return {
    "symbol": symbol,
    "name": data.get("name", symbol),
    ...
    "lot_size": 100,  # HKEX board lot
    "timestamp": datetime.now().isoformat(),
}
```

**Change TO:**
```python
# Get actual lot size from broker
actual_lot_size = 100  # Default
if hasattr(self.broker, 'get_lot_size'):
    try:
        actual_lot_size = self.broker.get_lot_size(symbol)
    except Exception as e:
        logger.warning(f"Could not get lot size for {symbol}: {e}")

return {
    "symbol": symbol,
    "name": data.get("name", symbol),
    ...
    "lot_size": actual_lot_size,  # Actual HKEX board lot for this stock
    "timestamp": datetime.now().isoformat(),
}
```

### Fix 2C: safety.py - Use stock-specific lot size

**File:** `catalyst-international/safety.py`
**Method:** `check_trade()`

The `check_trade()` method currently uses `self.limits.lot_size` which is hardcoded to 100.

**Option A (Simpler):** Pass lot_size as parameter to check_trade:

**Change the check_trade signature FROM:**
```python
def check_trade(
    self,
    symbol: str,
    side: str,
    quantity: int,
    entry_price: float,
    stop_loss: float,
    take_profit: float,
    portfolio_value: float,
    cash_available: float,
    current_positions: int,
    daily_pnl_pct: float = 0.0,
) -> SafetyCheckResult:
```

**TO:**
```python
def check_trade(
    self,
    symbol: str,
    side: str,
    quantity: int,
    entry_price: float,
    stop_loss: float,
    take_profit: float,
    portfolio_value: float,
    cash_available: float,
    current_positions: int,
    daily_pnl_pct: float = 0.0,
    lot_size: int = 100,  # NEW: Stock-specific lot size
) -> SafetyCheckResult:
```

**And change the lot size check FROM:**
```python
# Check 2: Lot size (HKEX requires multiples of 100)
if quantity % self.limits.lot_size != 0:
    return SafetyCheckResult(
        approved=False,
        reason=f"Quantity must be multiple of {self.limits.lot_size} (board lot)",
        ...
    )
```

**TO:**
```python
# Check 2: Lot size (HKEX requires multiples of board lot)
actual_lot_size = lot_size or self.limits.lot_size
if quantity % actual_lot_size != 0:
    return SafetyCheckResult(
        approved=False,
        reason=f"Quantity must be multiple of {actual_lot_size} (board lot for {symbol})",
        ...
    )
```

### Fix 2D: tools.py - Pass lot_size to check_risk

**File:** `catalyst-international/tools.py`
**Function:** Where `check_risk` tool calls `safety.check_trade()`

The tool handler needs to fetch the lot_size and pass it:

```python
# In the check_risk tool handler:
quote = market_data.get_quote(symbol)
lot_size = quote.get('lot_size', 100)

result = safety.check_trade(
    symbol=symbol,
    side=side,
    quantity=quantity,
    entry_price=entry_price,
    stop_loss=stop_loss,
    take_profit=take_profit,
    portfolio_value=portfolio_value,
    cash_available=cash_available,
    current_positions=current_positions,
    daily_pnl_pct=daily_pnl_pct,
    lot_size=lot_size,  # NEW: Pass stock-specific lot size
)
```

---

## Testing Plan

### Test Pattern Detection Fix
```bash
# After applying the fix, run a manual test:
cd /root/catalyst-international
python3 -c "
from data.market import MarketData
from data.patterns import PatternDetector
from brokers.moomoo import MoomooClient

# Initialize
client = MoomooClient()
client.connect()

market = MarketData(client)
detector = PatternDetector(market)

# Test pattern detection
patterns = detector.detect_patterns('0700', days=30)
print(f'Found {len(patterns)} patterns for Tencent')
for p in patterns:
    print(f'  - {p[\"pattern\"]}: confidence {p[\"confidence\"]}')
"
```

### Test Lot Size Fix
```bash
# Test lot size retrieval:
python3 -c "
from brokers.moomoo import MoomooClient

client = MoomooClient()
client.connect()

# Test various stocks
test_stocks = ['0700', '2628', '0001', '0462']
for symbol in test_stocks:
    lot_size = client.get_lot_size(symbol)
    print(f'{symbol}: lot_size = {lot_size}')
"
```

Expected output:
```
0700: lot_size = 100    # Tencent
2628: lot_size = 500    # China Life
0001: lot_size = 500    # CK Hutchison
0462: lot_size = 4000   # Natural Dairy
```

---

## Priority Order

1. **Fix 1 FIRST** - Pattern detection is completely broken, nothing else can work
2. **Fix 2A** - Add `get_lot_size()` to moomoo.py
3. **Fix 2B** - Update market.py to return actual lot size
4. **Fix 2C** - Update safety.py to use stock-specific lot size
5. **Fix 2D** - Update tools.py to pass lot_size

---

## Version Updates After Fixes

| File | Current | After Fix |
|------|---------|-----------|
| patterns.py | 1.1.0 | 1.2.0 |
| moomoo.py | 1.2.0 | 1.3.0 |
| market.py | (check) | +0.1.0 |
| safety.py | (check) | +0.1.0 |
| tools.py | (check) | +0.1.0 |

---

## Deployment Checklist

- [ ] SSH to droplet
- [ ] Apply patterns.py fix
- [ ] Test pattern detection
- [ ] Apply moomoo.py get_lot_size() addition
- [ ] Apply moomoo.py execute_trade() update
- [ ] Apply market.py get_quote() update
- [ ] Apply safety.py check_trade() update
- [ ] Apply tools.py check_risk handler update
- [ ] Test lot size retrieval
- [ ] Test full trading cycle
- [ ] Update GitHub with new versions
- [ ] Monitor next trading session

---

**End of Implementation Guide**
