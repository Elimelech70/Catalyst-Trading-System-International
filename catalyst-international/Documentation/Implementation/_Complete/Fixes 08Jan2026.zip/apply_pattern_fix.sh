#!/bin/bash
# ============================================================================
# QUICK FIX SCRIPT - Apply Pattern Detection Fix
# Run this on your DigitalOcean droplet
# ============================================================================

echo "=================================================="
echo "Catalyst International - Pattern Detection Fix"
echo "=================================================="

# Backup original file
PATTERNS_FILE="/root/catalyst-international/data/patterns.py"

if [ ! -f "$PATTERNS_FILE" ]; then
    echo "ERROR: patterns.py not found at $PATTERNS_FILE"
    exit 1
fi

echo "Creating backup..."
cp "$PATTERNS_FILE" "${PATTERNS_FILE}.bak.$(date +%Y%m%d_%H%M%S)"

echo "Applying fix..."

# Use sed to replace get_ohlcv with get_historical
sed -i 's/self\.market_data\.get_ohlcv(symbol, days=days)/self.market_data.get_historical(symbol, timeframe="1d", bars=days)/g' "$PATTERNS_FILE"

# Update error message
sed -i 's/Failed to get OHLCV for/Failed to get historical data for/g' "$PATTERNS_FILE"

# Update version
sed -i 's/Version: 1\.1\.0/Version: 1.2.0/g' "$PATTERNS_FILE"
sed -i 's/Last Updated: 2026-01-06/Last Updated: 2026-01-08/g' "$PATTERNS_FILE"

echo "Fix applied!"
echo ""
echo "Verifying fix..."
grep -n "get_historical" "$PATTERNS_FILE" | head -5

echo ""
echo "=================================================="
echo "DONE! Pattern detection should now work."
echo "Test with a manual trading cycle."
echo "=================================================="
