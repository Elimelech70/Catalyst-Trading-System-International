# ============================================================================
# MARKET.PY PATCH FILE
# Update get_quote() to return actual lot size instead of hardcoded 100
# ============================================================================

# FIND THIS CODE in get_quote() method (around line 60-80):
"""
        return {
            "symbol": symbol,
            "name": data.get("name", symbol),
            "price": last_price,
            "bid": safe_float(data.get("bid_price") or data.get("bid")),
            "ask": safe_float(data.get("ask_price") or data.get("ask")),
            "volume": volume,
            "avg_volume": avg_volume,
            "volume_ratio": round(volume_ratio, 2),
            "change": round(change, 2),
            "change_pct": round(change_pct, 2),
            "day_high": safe_float(data.get("high_price") or data.get("high")),
            "day_low": safe_float(data.get("low_price") or data.get("low")),
            "open": safe_float(data.get("open_price") or data.get("open")),
            "prev_close": prev_close,
            "market_cap": safe_float(data.get("market_cap")),
            "lot_size": 100,  # HKEX board lot
            "timestamp": datetime.now().isoformat(),
        }
"""

# REPLACE WITH:
"""
        # Get actual lot size from broker (varies by stock)
        actual_lot_size = 100  # Default
        if hasattr(self.broker, 'get_lot_size'):
            try:
                actual_lot_size = self.broker.get_lot_size(symbol)
            except Exception as e:
                logger.warning(f"Could not get lot size for {symbol}: {e}")

        return {
            "symbol": symbol,
            "name": data.get("name", symbol),
            "price": last_price,
            "bid": safe_float(data.get("bid_price") or data.get("bid")),
            "ask": safe_float(data.get("ask_price") or data.get("ask")),
            "volume": volume,
            "avg_volume": avg_volume,
            "volume_ratio": round(volume_ratio, 2),
            "change": round(change, 2),
            "change_pct": round(change_pct, 2),
            "day_high": safe_float(data.get("high_price") or data.get("high")),
            "day_low": safe_float(data.get("low_price") or data.get("low")),
            "open": safe_float(data.get("open_price") or data.get("open")),
            "prev_close": prev_close,
            "market_cap": safe_float(data.get("market_cap")),
            "lot_size": actual_lot_size,  # Actual HKEX board lot for this stock
            "timestamp": datetime.now().isoformat(),
        }
"""
