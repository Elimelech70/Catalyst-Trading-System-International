# ============================================================================
# SAFETY.PY PATCH FILE  
# Update check_trade() to accept stock-specific lot size
# ============================================================================

# STEP 1: UPDATE METHOD SIGNATURE
# FIND the check_trade method signature:
"""
    def check_trade(
        self,
        symbol: str,
        side: str,
        quantity: int,
        entry_price: float,
        stop_loss: float,
        take_profit: float,
        portfolio_value: float,
        cash_available: float,
        current_positions: int,
        daily_pnl_pct: float = 0.0,
    ) -> SafetyCheckResult:
"""

# REPLACE WITH (add lot_size parameter):
"""
    def check_trade(
        self,
        symbol: str,
        side: str,
        quantity: int,
        entry_price: float,
        stop_loss: float,
        take_profit: float,
        portfolio_value: float,
        cash_available: float,
        current_positions: int,
        daily_pnl_pct: float = 0.0,
        lot_size: int = 100,  # NEW: Stock-specific lot size
    ) -> SafetyCheckResult:
"""


# STEP 2: UPDATE LOT SIZE CHECK
# FIND the lot size check (around line 80-90):
"""
        # Check 2: Lot size (HKEX requires multiples of 100)
        if quantity % self.limits.lot_size != 0:
            return SafetyCheckResult(
                approved=False,
                reason=f"Quantity must be multiple of {self.limits.lot_size} (board lot)",
                warnings=warnings,
                details=details,
            )
"""

# REPLACE WITH:
"""
        # Check 2: Lot size (HKEX requires multiples of board lot - varies by stock)
        actual_lot_size = lot_size if lot_size else self.limits.lot_size
        if quantity % actual_lot_size != 0:
            return SafetyCheckResult(
                approved=False,
                reason=f"Quantity must be multiple of {actual_lot_size} (board lot for {symbol})",
                warnings=warnings,
                details=details,
            )
"""


# STEP 3: UPDATE DOCSTRING
# Add to the docstring Args section:
"""
        lot_size: Board lot size for this specific stock (default 100).
            HKEX stocks have varying lot sizes:
            - Tencent (0700): 100
            - China Life (2628): 500
            - CK Hutchison (0001): 500
"""
