"""
Name of Application: Catalyst Trading System
Name of file: tool_executor_patch.py
Version: 1.0.0
Last Updated: 2026-01-06
Purpose: Patch instructions for integrating position monitor into tool_executor.py

INSTRUCTIONS:
Apply these changes to tool_executor.py to enable position monitoring after BUY trades.
"""

# =============================================================================
# CHANGE 1: Add imports at the top of tool_executor.py
# =============================================================================

IMPORTS_TO_ADD = '''
# Position monitoring (add after other imports)
import asyncio
from position_monitor import start_position_monitor
'''

# =============================================================================
# CHANGE 2: Update ToolExecutor.__init__ to accept agent reference
# =============================================================================

INIT_CHANGE = '''
# BEFORE:
def __init__(
    self,
    cycle_id: str,
    alert_callback: Any = None,
):
    self.cycle_id = cycle_id
    self.alert_callback = alert_callback
    # ...

# AFTER:
def __init__(
    self,
    cycle_id: str,
    alert_callback: Any = None,
    agent: Any = None,  # ADD THIS PARAMETER
):
    self.cycle_id = cycle_id
    self.alert_callback = alert_callback
    self.agent = agent  # ADD THIS LINE
    # ...
'''

# =============================================================================
# CHANGE 3: Update _execute_trade to start position monitor after BUY
# =============================================================================

EXECUTE_TRADE_ADDITION = '''
# Add this AFTER successful trade execution in _execute_trade method,
# inside the "if result.status in [...]:" block:

# Start position monitoring for BUY orders
if side.lower() == "buy" and self.agent:
    try:
        # Get the anthropic client from agent
        anthropic_client = getattr(self.agent, 'client', None)
        
        if anthropic_client:
            # Start async monitoring
            monitor_result = asyncio.run(
                start_position_monitor(
                    broker=self.broker,
                    market_data=self.market,
                    anthropic_client=anthropic_client,
                    safety_validator=self.safety,
                    symbol=symbol,
                    entry_price=fill_price or limit_price or 0,
                    quantity=quantity,
                    stop_price=stop_loss,
                    target_price=take_profit,
                    entry_reason=reason,
                )
            )
            logger.info(f"Position monitor result: {monitor_result}")
    except Exception as e:
        logger.error(f"Position monitor failed: {e}", exc_info=True)
        # Trade still succeeded, just monitoring failed
'''

# =============================================================================
# CHANGE 4: Update agent.py to pass self to executor
# =============================================================================

AGENT_CHANGE = '''
# In agent.py, find where ToolExecutor is created and add agent=self:

# BEFORE:
self.executor = create_tool_executor(
    cycle_id=self.cycle_id,
    alert_callback=alert_callback,
)

# AFTER:
self.executor = create_tool_executor(
    cycle_id=self.cycle_id,
    alert_callback=alert_callback,
    agent=self,  # ADD THIS LINE
)
'''

# =============================================================================
# COMPLETE PATCHED _execute_trade METHOD
# =============================================================================

PATCHED_EXECUTE_TRADE = '''
def _execute_trade(self, inputs: dict) -> dict:
    """Execute a trade with position monitoring."""
    symbol = inputs["symbol"]
    side = inputs["side"]
    quantity = inputs["quantity"]
    order_type = inputs["order_type"]
    limit_price = inputs.get("limit_price")
    stop_loss = inputs["stop_loss"]
    take_profit = inputs["take_profit"]
    reason = inputs["reason"]

    # Execute via broker
    result = self.broker.execute_trade(
        symbol=symbol,
        side=side,
        quantity=quantity,
        order_type=order_type,
        limit_price=limit_price,
        stop_loss=stop_loss,
        take_profit=take_profit,
        reason=reason,
    )

    # Handle OrderResult dataclass
    if hasattr(result, 'status'):
        status = result.status
        order_id = result.order_id
        fill_price = result.filled_price
    else:
        status = result.get('status', '')
        order_id = result.get('order_id', '')
        fill_price = result.get('filled_price') or result.get('fill_price')

    # Record in database if successful
    if status in ["Filled", "FILLED", "Submitted", "SUBMITTED", "success"]:
        self.trades_executed += 1
        self.safety.record_trade()

        # Record position
        try:
            self.db.record_position(
                symbol=symbol,
                side=side,
                quantity=quantity,
                entry_price=fill_price or limit_price or 0,
                stop_loss=stop_loss,
                take_profit=take_profit,
                broker_order_id=order_id,
                cycle_id=self.cycle_id,
                reason=reason,
            )
        except Exception as e:
            logger.error(f"Failed to record position: {e}")

        # Send alert
        if self.alert_callback:
            try:
                if hasattr(self.alert_callback, 'send'):
                    self.alert_callback.send(
                        "info",
                        f"Trade Executed: {side.upper()} {symbol}",
                        f"Executed {side} {quantity} {symbol}\\n"
                        f"Price: {fill_price or 'pending'}\\n"
                        f"Stop: {stop_loss}, Target: {take_profit}\\n"
                        f"Reason: {reason}",
                    )
                elif callable(self.alert_callback):
                    self.alert_callback(
                        "info",
                        f"Trade Executed: {side.upper()} {symbol}",
                        f"Executed {side} {quantity} {symbol}\\n"
                        f"Price: {fill_price or 'pending'}\\n"
                        f"Stop: {stop_loss}, Target: {take_profit}\\n"
                        f"Reason: {reason}",
                    )
            except Exception as e:
                logger.error(f"Alert failed: {e}")

        # ============================================================
        # NEW: Start position monitoring for BUY orders
        # ============================================================
        if side.lower() == "buy" and self.agent:
            try:
                anthropic_client = getattr(self.agent, 'client', None)
                
                if anthropic_client:
                    logger.info(f"Starting position monitor for {symbol}")
                    
                    monitor_result = asyncio.run(
                        start_position_monitor(
                            broker=self.broker,
                            market_data=self.market,
                            anthropic_client=anthropic_client,
                            safety_validator=self.safety,
                            symbol=symbol,
                            entry_price=fill_price or limit_price or 0,
                            quantity=quantity,
                            stop_price=stop_loss,
                            target_price=take_profit,
                            entry_reason=reason,
                        )
                    )
                    
                    logger.info(f"Position monitor completed: {monitor_result}")
                    
                    # Return includes monitoring result
                    return {
                        "status": "success",
                        "order_id": order_id,
                        "fill_price": fill_price,
                        "symbol": symbol,
                        "side": side,
                        "quantity": quantity,
                        "monitor_result": monitor_result,
                    }
                    
            except Exception as e:
                logger.error(f"Position monitor failed: {e}", exc_info=True)
                # Trade succeeded, monitoring failed - continue
        # ============================================================

        return {
            "status": "success",
            "order_id": order_id,
            "fill_price": fill_price,
            "symbol": symbol,
            "side": side,
            "quantity": quantity,
        }
    
    else:
        return {
            "status": "failed",
            "reason": getattr(result, 'message', str(result)),
            "symbol": symbol,
            "side": side,
            "quantity": quantity,
        }
'''

# =============================================================================
# DEPLOYMENT CHECKLIST
# =============================================================================

DEPLOYMENT_CHECKLIST = '''
DEPLOYMENT CHECKLIST
====================

1. [ ] Copy files to catalyst-international directory:
       - signals.py
       - consciousness_notify.py
       - position_monitor.py

2. [ ] Install asyncpg if not present:
       pip install asyncpg --break-system-packages

3. [ ] Update tool_executor.py:
       - Add imports (see IMPORTS_TO_ADD)
       - Update __init__ to accept agent parameter
       - Update _execute_trade to start monitoring

4. [ ] Update agent.py:
       - Pass agent=self to create_tool_executor()

5. [ ] Test signal detection:
       python3 signals.py

6. [ ] Test consciousness notifications:
       python3 consciousness_notify.py

7. [ ] Test full integration:
       python3 agent.py --force

8. [ ] Commit changes:
       git add signals.py consciousness_notify.py position_monitor.py
       git add tool_executor.py agent.py
       git commit -m "feat: Add position monitoring after BUY trades"
       git push origin main
'''

if __name__ == "__main__":
    print("Position Monitor Integration Patch")
    print("=" * 60)
    print(DEPLOYMENT_CHECKLIST)
