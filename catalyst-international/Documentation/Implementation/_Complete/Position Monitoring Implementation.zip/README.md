# Position Monitor Implementation

**Name of Application:** Catalyst Trading System  
**Version:** 1.1.0  
**Last Updated:** 2026-01-06  
**Purpose:** Continuous position monitoring from entry to exit

---

## Overview

This implementation provides continuous AI-powered position monitoring for HKEX trades. When a BUY order is executed, the monitor automatically starts and runs until the position is closed or the market closes.

### Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                    POSITION MONITORING FLOW                         │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  1. Agent executes BUY via tool_executor.py                         │
│     │                                                               │
│     ▼                                                               │
│  2. start_position_monitor() called automatically                   │
│     │                                                               │
│     ▼                                                               │
│  3. Monitoring Loop (every 5 minutes):                              │
│     ┌───────────────────────────────────────────────────────┐      │
│     │                                                       │      │
│     │  ┌─────────────┐   ┌─────────────┐   ┌─────────────┐ │      │
│     │  │ Get Quote   │──▶│ Detect      │──▶│ Decision    │ │      │
│     │  │ + Technicals│   │ Signals     │   │ Logic       │ │      │
│     │  └─────────────┘   │ (FREE)      │   └──────┬──────┘ │      │
│     │                    └─────────────┘          │        │      │
│     │                                             ▼        │      │
│     │                    ┌─────────────────────────────────┐│      │
│     │                    │ STRONG → Exit immediately      ││      │
│     │                    │ MODERATE (multi) → Exit        ││      │
│     │                    │ MODERATE (few) → Ask Haiku     ││      │
│     │                    │ WEAK/NONE → Hold              ││      │
│     │                    └─────────────────────────────────┘│      │
│     │                                                       │      │
│     └───────────────────────────────────────────────────────┘      │
│     │                                                               │
│     ▼                                                               │
│  4. Exit executed → Notify big_bro → Return P&L                     │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Cost Model

| Component | Cost | Notes |
|-----------|------|-------|
| Signal detection | **FREE** | Rules-based, no AI |
| Haiku consultation | ~$0.05/call | Only for uncertain signals |
| Big Bro notifications | **FREE** | Database writes only |
| **Per-trade total** | **~$0.05-0.15** | Max 10 Haiku calls |

---

## Files

| File | Purpose | Lines |
|------|---------|-------|
| `signals.py` | Exit signal detection (FREE) | ~350 |
| `consciousness_notify.py` | Big Bro notifications | ~250 |
| `position_monitor.py` | Main monitoring loop | ~450 |
| `tool_executor_patch.py` | Integration instructions | ~200 |

---

## Signal Thresholds

### P&L Signals

| Signal | STRONG | MODERATE | WEAK |
|--------|--------|----------|------|
| Stop Loss | ≤ -3% | -2% to -3% | -1% to -2% |
| Take Profit | ≥ +8% | +5% to +8% | +3% to +5% |
| Trailing Stop | 3% drawdown from high | 2% drawdown | - |

### Technical Signals

| Signal | STRONG | MODERATE | WEAK |
|--------|--------|----------|------|
| RSI Overbought | ≥ 85 | 75-85 | 70-75 |
| Volume Dying | < 25% of entry | 25-40% | 40-60% |
| Below VWAP | - | < 98% of VWAP | < VWAP |

### Time Signals (HKEX)

| Signal | STRONG | MODERATE | WEAK |
|--------|--------|----------|------|
| Market Closing | < 10 min (15:50) | < 30 min | < 60 min |
| Lunch Break | 11:50-12:00 | 11:30-11:50 | - |
| Time Stop (flat) | > 120 min | > 90 min | > 60 min |

---

## Deployment

### Step 1: Copy Files

```bash
ssh root@137.184.244.45

cd /root/Catalyst-Trading-System-International/catalyst-international

# Copy the files (or use scp/git)
# signals.py
# consciousness_notify.py
# position_monitor.py
```

### Step 2: Install Dependencies

```bash
source venv/bin/activate
pip install asyncpg --break-system-packages
```

### Step 3: Test Signal Detection

```bash
python3 signals.py
```

Expected output:
```
Testing Exit Signal Detection v1.1.0
============================================================

Test 1: Position down 3% (should EXIT immediately)
  Signals: ['stop_loss_hit:STRONG']
  Decision: EXIT (confidence: 95%)

Test 2: Position up 8% (should EXIT - take profit)
  Signals: ['take_profit_hit:STRONG', 'rsi_overbought:WEAK']
  Decision: EXIT (confidence: 95%)
...
```

### Step 4: Test Notifications

```bash
# Set database URL first
export RESEARCH_DATABASE_URL='postgresql://...'

python3 consciousness_notify.py
```

### Step 5: Update tool_executor.py

Add imports at top:
```python
import asyncio
from position_monitor import start_position_monitor
```

Update `__init__`:
```python
def __init__(
    self,
    cycle_id: str,
    alert_callback: Any = None,
    agent: Any = None,  # ADD THIS
):
    # ...
    self.agent = agent  # ADD THIS
```

Update `_execute_trade` - see `tool_executor_patch.py` for full code.

### Step 6: Update agent.py

```python
# In run_cycle(), update executor creation:
self.executor = create_tool_executor(
    cycle_id=self.cycle_id,
    alert_callback=alert_callback,
    agent=self,  # ADD THIS LINE
)
```

### Step 7: Test Full Integration

```bash
python3 agent.py --force
```

### Step 8: Commit

```bash
git add signals.py consciousness_notify.py position_monitor.py
git add tool_executor.py agent.py
git commit -m "feat: Add continuous position monitoring

- Rules-based signal detection (FREE)
- Haiku consultation for uncertain signals (~$0.05)
- Big Bro notifications via consciousness DB
- Automatic monitoring from entry to exit"
git push origin main
```

---

## Monitoring Dashboard

Check position monitor activity via consciousness MCP:

```
# Get recent observations
catalyst-consciousness:get_observations agent_id=intl_claude limit=10

# Get messages to big_bro
catalyst-consciousness:get_messages agent_id=intl_claude limit=10
```

---

## Troubleshooting

### Monitor Not Starting

1. Check `agent.py` passes `agent=self` to executor
2. Check `tool_executor.py` has `agent` parameter in `__init__`
3. Check imports are correct

### Haiku Calls Failing

1. Verify `ANTHROPIC_API_KEY` is set
2. Check API budget hasn't been exceeded
3. Review logs: `tail -f logs/agent.log`

### Database Connection Errors

1. Verify `RESEARCH_DATABASE_URL` is set
2. Check asyncpg is installed: `pip list | grep asyncpg`
3. Test connection: `python3 consciousness_notify.py`

---

## Future Improvements

- [ ] Add support for SHORT positions
- [ ] Implement adaptive check intervals (faster when volatile)
- [ ] Add pattern break detection
- [ ] Support multiple simultaneous positions
- [ ] Add websocket for real-time updates

---

*Catalyst Trading System - Position Monitor v1.1.0*
